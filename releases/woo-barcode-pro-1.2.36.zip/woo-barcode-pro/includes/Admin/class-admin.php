<?php
/**
 * Admin menu, enqueue, metabox, and product column.
 *
 * @package WCBarcodePro\Admin
 */

namespace WCBarcodePro\Admin;

defined( 'ABSPATH' ) || exit;

class Admin {

	private static ?Admin $instance = null;

	public static function get_instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function register_hooks(): void {
		add_action( 'admin_menu',                   array( $this, 'register_menu_pages' ) );
		add_action( 'admin_enqueue_scripts',        array( $this, 'enqueue_scripts' ) );
		add_action( 'admin_notices',                array( $this, 'show_welcome_notice' ) );
		add_action( 'wp_ajax_wcbp_dismiss_notice',      array( $this, 'ajax_dismiss_notice' ) );
		add_action( 'wp_ajax_wcbp_get_barcode_preview', array( $this, 'ajax_barcode_preview' ) );
		add_action( 'add_meta_boxes',               array( $this, 'add_product_metabox' ) );
		add_action( 'save_post_product',            array( $this, 'save_product_metabox' ), 10, 1 );
		add_filter( 'manage_edit-product_columns',  array( $this, 'add_barcode_column' ) );
		add_action( 'manage_product_posts_custom_column', array( $this, 'render_barcode_column' ), 10, 2 );
		add_filter( 'bulk_actions-edit-product',    array( $this, 'register_bulk_actions' ) );
		add_filter( 'handle_bulk_actions-edit-product', array( $this, 'handle_bulk_action_add_queue' ), 10, 3 );
	}

	public function register_menu_pages(): void {
		add_menu_page(
			__( 'WooBarcode Pro', 'woo-barcode-pro' ),
			__( 'Barcode Pro', 'woo-barcode-pro' ),
			'manage_woocommerce',
			'wcbp-settings',
			array( Settings::get_instance(), 'render_page' ),
			'dashicons-tag',
			58
		);
		add_submenu_page( 'wcbp-settings', __( 'Settings', 'woo-barcode-pro' ),        __( 'Settings', 'woo-barcode-pro' ),        'manage_woocommerce', 'wcbp-settings',        array( Settings::get_instance(),      'render_page' ) );
		add_submenu_page( 'wcbp-settings', __( 'Label Templates', 'woo-barcode-pro' ),  __( 'Label Templates', 'woo-barcode-pro' ),  'manage_woocommerce', 'wcbp-label-templates',  array( LabelTemplates::get_instance(), 'render_page' ) );
		add_submenu_page( 'wcbp-settings', __( 'Price Templates', 'woo-barcode-pro' ),  __( 'Price Templates', 'woo-barcode-pro' ),  'manage_woocommerce', 'wcbp-price-templates',  array( PriceTemplates::get_instance(), 'render_page' ) );
		add_submenu_page( 'wcbp-settings', __( 'Print Queue', 'woo-barcode-pro' ),      __( 'Print Queue', 'woo-barcode-pro' ),      'manage_woocommerce', 'wcbp-print-queue',      array( PrintQueue::get_instance(),    'render_page' ) );
		add_submenu_page( 'wcbp-settings', __( 'Quick Add', 'woo-barcode-pro' ),        __( '📱 Quick Add', 'woo-barcode-pro' ),    'manage_woocommerce', 'wcbp-quick-add',        array( QuickAdd::get_instance(),      'render_page' ) );
		add_submenu_page( 'wcbp-settings', __( 'Inventory', 'woo-barcode-pro' ),       __( 'Inventory', 'woo-barcode-pro' ),       'manage_woocommerce', 'wcbp-inventory',        array( \WCBarcodePro\Inventory\InventoryManager::get_instance(), 'render_page' ) );
		add_submenu_page( 'wcbp-settings', __( 'Batch Create', 'woo-barcode-pro' ),    __( '⚡ Batch Create', 'woo-barcode-pro' ),  'manage_woocommerce', 'wcbp-batch-create',     array( BatchCreate::get_instance(), 'render_page' ) );
		add_submenu_page( 'wcbp-settings', __( 'Stock View', 'woo-barcode-pro' ),      __( '📦 Stock View', 'woo-barcode-pro' ),    'manage_woocommerce', 'wcbp-stock-view',        array( StockView::get_instance(),   'render_page' ) );
		// Tutorial — hidden from nav but accessible via URL.
		add_submenu_page( null,            __( 'Tutorial', 'woo-barcode-pro' ),         __( 'Tutorial', 'woo-barcode-pro' ),         'manage_woocommerce', 'wcbp-tutorial',         array( Tutorial::get_instance(),      'render_page' ) );
		// Print page — hidden, full-screen.
		add_submenu_page( null,            __( 'Print Labels', 'woo-barcode-pro' ),     __( 'Print Labels', 'woo-barcode-pro' ),     'manage_woocommerce', 'wcbp-print',            array( PrintPage::get_instance(),     'render_page' ) );
	}

	public function enqueue_scripts( string $hook ): void {
		$screen = get_current_screen();
		if ( ! $screen ) {
			return;
		}

		wp_enqueue_style( 'wcbp-admin', WCBP_PLUGIN_URL . 'assets/css/admin.css', array(), WCBP_VERSION );

		$wcbp_pages  = array( 'wcbp-settings', 'wcbp-label-templates', 'wcbp-price-templates', 'wcbp-print-queue', 'wcbp-quick-add', 'wcbp-tutorial', 'wcbp-print', 'wcbp-inventory', 'wcbp-batch-create', 'wcbp-stock-view' );
		$page        = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security
		$on_product  = 'product' === $screen->post_type && in_array( $screen->base, array( 'post', 'edit' ), true );

		if ( in_array( $page, $wcbp_pages, true ) || $on_product ) {
			wp_enqueue_script( 'wcbp-admin', WCBP_PLUGIN_URL . 'assets/js/admin.js', array( 'jquery' ), WCBP_VERSION, true );
			wp_localize_script( 'wcbp-admin', 'wcbpAdmin', array(
				'ajax_url'   => admin_url( 'admin-ajax.php' ),
				'nonce'      => wp_create_nonce( 'wcbp_admin' ),
				'queue_nonce'=> wp_create_nonce( 'wcbp_queue' ),
				'plugin_url' => WCBP_PLUGIN_URL,
				'strings'    => array(
					'adding'          => __( 'Adding…', 'woo-barcode-pro' ),
					'added'           => __( 'Added!', 'woo-barcode-pro' ),
					'added_one'       => __( '+1 Added!', 'woo-barcode-pro' ),
					'error'           => __( 'Error', 'woo-barcode-pro' ),
					'select_products' => __( 'Please select products first.', 'woo-barcode-pro' ),
				),
			) );
		}

		if ( 'wcbp-label-templates' === $page ) {
			wp_enqueue_media();
			wp_enqueue_script(  'wcbp-label-designer',   WCBP_PLUGIN_URL . 'assets/js/label-designer.js',   array( 'jquery' ), WCBP_VERSION, true );
			wp_enqueue_style(   'wcbp-visual-designer',  WCBP_PLUGIN_URL . 'assets/css/visual-designer.css', array(), WCBP_VERSION );
			wp_enqueue_script(  'wcbp-visual-designer',  WCBP_PLUGIN_URL . 'assets/js/visual-designer.js',   array(), WCBP_VERSION, true );
			wp_localize_script( 'wcbp-label-designer', 'wcbpDesigner', array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'wcbp_admin' ),
				'presets'  => LabelTemplates::get_instance()->get_preset_dimensions(),
				'strings'  => array(
					'select_logo' => __( 'Select Logo Image', 'woo-barcode-pro' ),
					'use_image'   => __( 'Use This Image', 'woo-barcode-pro' ),
				),
			) );
		}

		if ( 'wcbp-print-queue' === $page ) {
			wp_enqueue_script( 'wcbp-print-queue', WCBP_PLUGIN_URL . 'assets/js/print-queue.js', array( 'jquery' ), WCBP_VERSION, true );
			wp_localize_script( 'wcbp-print-queue', 'wcbpQueue', array(
				'ajax_url'  => admin_url( 'admin-ajax.php' ),
				'admin_url' => admin_url( 'admin.php' ),
				'nonce'     => wp_create_nonce( 'wcbp_queue' ),
				'strings'   => array(
					'confirm_clear' => __( 'Clear all items from the queue?', 'woo-barcode-pro' ),
					'popup_blocked' => __( 'Please allow popups for this site.', 'woo-barcode-pro' ),
				),
			) );
		}

		if ( 'wcbp-quick-add' === $page ) {
			wp_enqueue_style(  'wcbp-quick-add', WCBP_PLUGIN_URL . 'assets/css/quick-add.css', array(), WCBP_VERSION );
			wp_enqueue_script( 'wcbp-quick-add', WCBP_PLUGIN_URL . 'assets/js/quick-add.js', array(), WCBP_VERSION, true );
			wp_localize_script( 'wcbp-quick-add', 'wcbpQuickAdd', array(
				'ajax_url'   => admin_url( 'admin-ajax.php' ),
				'nonce'      => wp_create_nonce( 'wcbp_quick_add' ),
				'inv_nonce'  => wp_create_nonce( 'wcbp_inventory' ),
				'plugin_url' => WCBP_PLUGIN_URL,
			) );
		}

		if ( 'wcbp-print' === $page ) {
			wp_enqueue_style( 'wcbp-print', WCBP_PLUGIN_URL . 'assets/css/print.css', array(), WCBP_VERSION );
		}

		if ( 'wcbp-inventory' === $page ) {
			wp_enqueue_script( 'wcbp-inventory', WCBP_PLUGIN_URL . 'assets/js/inventory.js', array( 'jquery' ), WCBP_VERSION, true );
			wp_localize_script( 'wcbp-inventory', 'wcbpInv', array(
				'ajax_url'  => admin_url( 'admin-ajax.php' ),
				'nonce'     => wp_create_nonce( 'wcbp_inventory' ),
				'edit_url'  => admin_url( 'post.php?post=' ),
				'order_url' => admin_url( 'post.php?post=' ),
				'strings'   => array(
					'not_found'       => __( 'No product found for that barcode or SKU.', 'woo-barcode-pro' ),
					'loading'         => __( 'Loading…', 'woo-barcode-pro' ),
					'saving'          => __( 'Saving…', 'woo-barcode-pro' ),
					'error'           => __( 'An error occurred.', 'woo-barcode-pro' ),
					'invalid_qty'     => __( 'Please enter a valid quantity (0 or more).', 'woo-barcode-pro' ),
					'set_stock'       => __( 'Set Stock', 'woo-barcode-pro' ),
					'confirm_sell'    => __( 'Deduct 1 unit from stock as an in-person sale?', 'woo-barcode-pro' ),
					'adjusted'        => __( 'Stock updated: %old% → %new% (%change%)', 'woo-barcode-pro' ),
					'sold_one'        => __( 'Sold 1 unit. New stock: %qty%', 'woo-barcode-pro' ),
					'no_low_stock'    => __( 'No products below that threshold.', 'woo-barcode-pro' ),
					'no_log'          => __( 'No history found.', 'woo-barcode-pro' ),
					'reason_order'    => __( 'Order sale', 'woo-barcode-pro' ),
					'reason_manual'   => __( 'Manual adjust', 'woo-barcode-pro' ),
					'reason_scan_sell'    => __( 'In-person sale', 'woo-barcode-pro' ),
					'draft_price_prefix'  => __( 'Price: ', 'woo-barcode-pro' ),
					'uploading'           => __( 'Uploading photo…', 'woo-barcode-pro' ),
					'photo_ready'         => __( 'Photo ready ✓', 'woo-barcode-pro' ),
					'upload_failed'       => __( 'Photo upload failed.', 'woo-barcode-pro' ),
					'publishing'          => __( 'Publishing…', 'woo-barcode-pro' ),
					'publish_btn'         => __( '✓ Publish Product', 'woo-barcode-pro' ),
					'published_ok'        => __( 'Product published!', 'woo-barcode-pro' ),
					'view_product'        => __( 'Edit →', 'woo-barcode-pro' ),
					'no_camera_api'       => __( 'Live scanning not supported on this browser. Please type the barcode manually.', 'woo-barcode-pro' ),
					'camera_error'        => __( 'Could not access camera:', 'woo-barcode-pro' ),
				),
			) );
		}

		if ( 'wcbp-batch-create' === $page ) {
			wp_enqueue_script( 'wcbp-batch-create', WCBP_PLUGIN_URL . 'assets/js/batch-create.js', array( 'jquery' ), WCBP_VERSION, true );
			wp_localize_script( 'wcbp-batch-create', 'wcbpBatch', array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'wcbp_batch_create' ),
				'strings'  => array(
					'select_template' => __( 'Please select a price template.', 'woo-barcode-pro' ),
					'invalid_qty'     => __( 'Please enter a valid quantity (1–500).', 'woo-barcode-pro' ),
					'creating'        => __( 'Creating…', 'woo-barcode-pro' ),
					'creating_n'      => __( 'Creating %n% draft products…', 'woo-barcode-pro' ),
					'create_btn'      => __( 'Create Draft Products', 'woo-barcode-pro' ),
					'success'         => __( '%n% draft products created and added to print queue.', 'woo-barcode-pro' ),
					'success_same'    => __( '1 product created with %n% units in stock and added to print queue.', 'woo-barcode-pro' ),
					'creating_n_same' => __( 'Creating 1 product with %n% units in stock…', 'woo-barcode-pro' ),
					'go_to_queue'     => __( 'Go to Print Queue', 'woo-barcode-pro' ),
					'print_now'       => __( 'Print Now', 'woo-barcode-pro' ),
					'show_skus'       => __( 'Show generated SKUs', 'woo-barcode-pro' ),
					'error'           => __( 'An error occurred. Please try again.', 'woo-barcode-pro' ),
				),
			) );
		}

		if ( 'wcbp-tutorial' === $page ) {
			wp_enqueue_style(  'wcbp-tutorial', WCBP_PLUGIN_URL . 'assets/css/tutorial.css', array(), WCBP_VERSION );
			wp_enqueue_script( 'wcbp-tutorial',  WCBP_PLUGIN_URL . 'assets/js/tutorial.js', array( 'jquery' ), WCBP_VERSION, true );
			wp_localize_script( 'wcbp-tutorial', 'wcbpTutorial', array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'wcbp_tutorial' ),
			) );
		}
	}

	public function show_welcome_notice(): void {
		if ( ! get_transient( 'wcbp_just_activated' ) ) {
			return;
		}
		if ( ! \WCBarcodePro\wcbp_current_user_can_manage() ) {
			return;
		}
		$tutorial_url = admin_url( 'admin.php?page=wcbp-tutorial' );
		?>
		<div class="notice notice-info wcbp-welcome-notice is-dismissible" style="padding:12px 15px;display:flex;align-items:center;gap:16px;">
			<span style="font-size:2rem;">🎉</span>
			<div>
				<strong><?php esc_html_e( 'WooBarcode Pro is active!', 'woo-barcode-pro' ); ?></strong>
				<?php esc_html_e( 'Start the 5-minute tour to set up your first barcode labels.', 'woo-barcode-pro' ); ?>
				&nbsp;<a href="<?php echo esc_url( $tutorial_url ); ?>" class="button button-primary" style="margin-left:8px;">
					<?php esc_html_e( 'Start Tutorial →', 'woo-barcode-pro' ); ?>
				</a>
				<a href="#" class="wcbp-dismiss-welcome" style="margin-left:8px;color:#999;">
					<?php esc_html_e( 'Dismiss', 'woo-barcode-pro' ); ?>
				</a>
			</div>
		</div>
		<script>
		document.querySelector('.wcbp-dismiss-welcome')?.addEventListener('click', function(e){
			e.preventDefault();
			fetch('<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>', {
				method:'POST',
				headers:{'Content-Type':'application/x-www-form-urlencoded'},
				body:'action=wcbp_dismiss_notice&nonce=<?php echo esc_js( wp_create_nonce( 'wcbp_dismiss' ) ); ?>'
			});
			this.closest('.wcbp-welcome-notice').remove();
		});
		</script>
		<?php
	}

	public function ajax_barcode_preview(): void {
		check_ajax_referer( 'wcbp_admin', 'nonce' );
		$product_id = (int) ( $_POST['id'] ?? 0 );
		$raw_value  = sanitize_text_field( wp_unslash( $_POST['value'] ?? '' ) );

		if ( $product_id ) {
			$svg = \WCBarcodePro\wcbp_product_barcode_svg( $product_id, 0, array( 'height' => 50, 'module_width' => 1 ) );
		} elseif ( '' !== $raw_value ) {
			$symbology = \WCBarcodePro\wcbp_get_setting( 'symbology', 'code128' );
			$svg = \WCBarcodePro\Barcode\BarcodeGenerator::get_instance()->generate_svg(
				$raw_value, $symbology, array( 'height' => 50, 'module_width' => 1 )
			);
		} else {
			wp_send_json_error();
			return;
		}

		if ( '' === $svg ) {
			wp_send_json_error( array( 'message' => __( 'Could not generate barcode.', 'woo-barcode-pro' ) ) );
			return;
		}

		wp_send_json_success( array( 'svg' => $svg ) );
	}

	public function ajax_dismiss_notice(): void {
		check_ajax_referer( 'wcbp_dismiss', 'nonce' );
		delete_transient( 'wcbp_just_activated' );
		wp_die( '1' );
	}

	public function add_product_metabox(): void {
		add_meta_box(
			'wcbp_product_barcode',
			__( 'Barcode', 'woo-barcode-pro' ),
			array( $this, 'render_product_metabox' ),
			'product',
			'side',
			'default'
		);
	}

	public function render_product_metabox( \WP_Post $post ): void {
		$product_id         = $post->ID;
		$svg                = \WCBarcodePro\wcbp_product_barcode_svg( $product_id, 0, array( 'height' => 50, 'module_width' => 1 ) );
		$value              = \WCBarcodePro\wcbp_barcode_value( $product_id );
		$ean                = \WCBarcodePro\Barcode\EanManager::get_instance()->get_ean( $product_id );
		$product            = wc_get_product( $product_id );
		$stock_qty          = ( $product && $product->managing_stock() ) ? max( 1, (int) $product->get_stock_quantity() ) : 1;
		$saved_label_tpl_id = (int) get_post_meta( $product_id, '_wcbp_label_template_id', true );
		$label_templates    = LabelTemplates::get_instance()->get_all();
		wp_nonce_field( 'wcbp_metabox', 'wcbp_metabox_nonce' );
		?>
		<div class="wcbp-metabox">
			<div id="wcbp-barcode-preview" class="wcbp-metabox-preview">
				<?php if ( $svg ) : ?>
					<?php echo $svg; // phpcs:ignore WordPress.Security ?>
					<p class="wcbp-metabox-value"><code><?php echo esc_html( $value ); ?></code></p>
				<?php else : ?>
					<p class="description"><?php esc_html_e( 'No barcode yet. Save the product or add a SKU.', 'woo-barcode-pro' ); ?></p>
				<?php endif; ?>
			</div>

			<p>
				<label><strong><?php esc_html_e( 'EAN / Custom Barcode', 'woo-barcode-pro' ); ?></strong></label>
				<input type="text" name="wcbp_ean" id="wcbp_ean"
					value="<?php echo esc_attr( $ean ); ?>"
					placeholder="<?php esc_attr_e( 'Optional EAN-13 or custom', 'woo-barcode-pro' ); ?>"
					class="widefat" />
			</p>

			<?php if ( ! empty( $label_templates ) ) : ?>
			<p>
				<label for="wcbp_label_template_id"><strong><?php esc_html_e( 'Label Template', 'woo-barcode-pro' ); ?></strong></label>
				<select name="wcbp_label_template_id" id="wcbp_label_template_id" style="width:100%;margin-top:4px;">
					<option value="0"><?php esc_html_e( '— Default template —', 'woo-barcode-pro' ); ?></option>
					<?php foreach ( $label_templates as $lt ) : ?>
						<option value="<?php echo esc_attr( $lt['id'] ); ?>" <?php selected( $saved_label_tpl_id, (int) $lt['id'] ); ?>>
							<?php echo esc_html( $lt['name'] ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</p>
			<?php endif; ?>

			<p style="display:flex;gap:6px;flex-wrap:wrap;">
				<button type="button" class="button wcbp-add-stock-queue"
					data-product-id="<?php echo esc_attr( (string) $product_id ); ?>"
					data-stock-qty="<?php echo esc_attr( (string) $stock_qty ); ?>">
					<?php esc_html_e( 'Add Stock To Print', 'woo-barcode-pro' ); ?>
				</button>
				<button type="button" class="button wcbp-add-one-queue"
					data-product-id="<?php echo esc_attr( (string) $product_id ); ?>">
					<?php esc_html_e( 'Add to Queue +1', 'woo-barcode-pro' ); ?>
				</button>
			</p>
			<?php if ( $product && $product->is_type( 'variable' ) ) : ?>
				<p class="description"><?php esc_html_e( 'Variable product: each variation is queued with its own barcode, stock count and attributes.', 'woo-barcode-pro' ); ?></p>
			<?php endif; ?>
		</div>
		<?php
	}

	public function save_product_metabox( int $product_id ): void {
		if ( ! isset( $_POST['wcbp_metabox_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wcbp_metabox_nonce'] ) ), 'wcbp_metabox' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $product_id ) ) {
			return;
		}
		if ( isset( $_POST['wcbp_ean'] ) ) {
			$ean = sanitize_text_field( wp_unslash( $_POST['wcbp_ean'] ) );
			if ( '' !== $ean ) {
				update_post_meta( $product_id, \WCBarcodePro\Barcode\EanManager::META_KEY, $ean );
			} else {
				delete_post_meta( $product_id, \WCBarcodePro\Barcode\EanManager::META_KEY );
			}
		}
		if ( isset( $_POST['wcbp_label_template_id'] ) ) {
			$tpl_id = (int) $_POST['wcbp_label_template_id'];
			if ( $tpl_id > 0 ) {
				update_post_meta( $product_id, '_wcbp_label_template_id', $tpl_id );
			} else {
				delete_post_meta( $product_id, '_wcbp_label_template_id' );
			}
		}
	}

	public function add_barcode_column( array $columns ): array {
		$new = array();
		foreach ( $columns as $key => $label ) {
			$new[ $key ] = $label;
			if ( 'sku' === $key ) {
				$new['wcbp_barcode'] = __( 'Barcode', 'woo-barcode-pro' );
			}
		}
		return $new;
	}

	public function render_barcode_column( string $column, int $post_id ): void {
		if ( 'wcbp_barcode' !== $column ) {
			return;
		}
		$product     = wc_get_product( $post_id );
		$is_variable = $product && $product->is_type( 'variable' );
		$svg         = $is_variable ? '' : \WCBarcodePro\wcbp_product_barcode_svg( $post_id, 0, array( 'height' => 32, 'module_width' => 1, 'show_text' => false ) );
		if ( $svg || $is_variable ) {
			$stock_qty = ( $product && $product->managing_stock() ) ? max( 1, (int) $product->get_stock_quantity() ) : 1;
			if ( $is_variable ) {
				$n = count( PrintQueue::get_instance()->get_variations( $post_id ) );
				/* translators: %d: number of variations */
				echo '<span class="description">' . esc_html( sprintf( _n( '%d variation — one barcode each', '%d variations — one barcode each', $n, 'woo-barcode-pro' ), $n ) ) . '</span>';
			} else {
				echo $svg; // phpcs:ignore WordPress.Security
			}
			echo '<br><button type="button" class="button button-small wcbp-add-stock-queue"' .
				' data-product-id="' . esc_attr( (string) $post_id ) . '"' .
				' data-stock-qty="' . esc_attr( (string) $stock_qty ) . '">' .
				esc_html__( 'Add Stock To Print', 'woo-barcode-pro' ) . '</button>' .
				'&nbsp;<button type="button" class="button button-small wcbp-add-one-queue"' .
				' data-product-id="' . esc_attr( (string) $post_id ) . '">' .
				esc_html__( '+1', 'woo-barcode-pro' ) . '</button>';
		} else {
			echo '<span class="wcbp-no-barcode">—</span>';
		}
	}

	public function register_bulk_actions( array $actions ): array {
		$actions['wcbp_add_to_queue'] = __( 'Add to Print Queue', 'woo-barcode-pro' );
		return $actions;
	}

	public function handle_bulk_action_add_queue( string $redirect_to, string $action, array $post_ids ): string {
		if ( 'wcbp_add_to_queue' !== $action ) {
			return $redirect_to;
		}
		$count = PrintQueue::get_instance()->handle_bulk_add( $post_ids );
		return add_query_arg( 'wcbp_queued', $count, $redirect_to );
	}
}
