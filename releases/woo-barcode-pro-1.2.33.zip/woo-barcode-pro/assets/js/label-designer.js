/* global wcbpDesigner, jQuery */
(function ($) {
	'use strict';

	var presets       = wcbpDesigner.presets || {};
	var LINEAR        = { code128: true, itf14: true };
	var _barcodeCache = {};
	var _barcodeTimer = null;

	// ── Preset selector ──────────────────────────────────────────────────────
	$('#wcbp-preset').on('change', function () {
		var key = $(this).val();
		var p   = presets[key];
		if (!p) return;
		$('#wcbp-width-in').val(p.width_in);
		$('#wcbp-height-in').val(p.height_in);
		$('#wcbp-cols').val(p.cols);
		$('#wcbp-rows-per-page').val(p.rows_per_page);
		$('#wcbp-gap-in').val(p.gap_in);
		$('#wcbp-margin-in').val(p.margin_in);
		schedulePreview();
	});

	// ── Barcode design params ────────────────────────────────────────────────
	function getBarcodeParams() {
		return {
			sym:      $('#wcbp-bc-symbology').val()          || 'code128',
			showText: $('#wcbp-bc-show-text').is(':checked') ? '1' : '0',
			mw:       $('#wcbp-bc-module-width').val()       || '2',
			color:    $('#wcbp-bc-color').val()              || '#000000',
			height:   $('#wcbp-bc-height').val()             || '60',
		};
	}

	function barcodeKey(value, p) {
		return value + '|' + p.sym + '|' + p.showText + '|' + p.mw + '|' + p.color + '|' + p.height;
	}

	// ── Barcode AJAX (cached + debounced) ────────────────────────────────────
	function fetchBarcode(value, params, callback) {
		if (!value) { callback(''); return; }
		var key = barcodeKey(value, params);
		if (_barcodeCache[key] !== undefined) { callback(_barcodeCache[key]); return; }
		$.post(wcbpDesigner.ajax_url, {
			action      : 'wcbp_preview_barcode',
			nonce       : wcbpDesigner.nonce,
			value       : value,
			symbology   : params.sym,
			show_text   : LINEAR[params.sym] ? '0' : params.showText,
			module_width: params.mw,
			color       : params.color,
			bc_height   : params.height,
		}, function (res) {
			var svg = (res.success && res.data && res.data.svg) ? res.data.svg : '';
			_barcodeCache[key] = svg;
			callback(svg);
		}).fail(function () {
			_barcodeCache[key] = '';
			callback('');
		});
	}

	// Make the SVG fill its container while keeping aspect ratio.
	function responsiveSvg(svg) {
		return svg
			.replace(/(<svg[^>]*)\swidth="\d+(\.\d+)?"/, '$1 width="100%"')
			.replace(/(<svg[^>]*)\sheight="\d+(\.\d+)?"/, '$1 height="100%"');
	}

	// Minimal XSS escape for text inserted as innerHTML.
	function esc(str) {
		return $('<span>').text(String(str)).html();
	}

	var BC_PLACEHOLDER = '<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:#f5f5f5;color:#bbb;font-size:9px;font-family:monospace">▊▋▊▌▋▊▋</div>';

	// Mirrors LabelRenderer::barcode_html() + BarcodeGenerator::svg_open() so preview == print.
	function barcodeBlock(svg, availIn) {
		if (!svg) { return BC_PLACEHOLDER; }
		var p  = getBarcodeParams();
		var vb = /viewBox="0 0 (\d+) (\d+)"/.exec(svg);
		if (!vb) { return responsiveSvg(svg); }

		var vbW = parseInt(vb[1], 10), vbH = parseInt(vb[2], 10);
		var modules = vbW / (parseInt(p.mw, 10) || 2);
		var avail = Math.max(0.2, availIn - 0.02);
		var moduleIn = avail / Math.max(1, modules);
		var steps = [0.02, 0.01, 1 / 150];
		for (var i = 0; i < steps.length; i++) {
			if (modules * steps[i] <= avail) { moduleIn = steps[i]; break; }
		}
		var wPx = modules * moduleIn * 96;
		var linear = !!LINEAR[p.sym];
		var textInSvg = !linear && p.showText === '1';

		svg = svg
			.replace(/(<svg[^>]*?)\swidth="[^"]*"/, '$1 width="' + wPx.toFixed(2) + 'px"')
			.replace(/(<svg[^>]*?)\sheight="[^"]*"/, '$1 height="' + (textInSvg ? (wPx * vbH / vbW).toFixed(2) + 'px' : '100%') + '"')
			.replace('<svg ', '<svg style="display:block;max-width:100%;min-height:0;flex:' + (textInSvg ? '0 1 auto' : '1 1 0') + '"' + (textInSvg ? '' : ' preserveAspectRatio="none"') + ' ');

		var text = '';
		if (linear && p.showText === '1') {
			var val = $('#wcbp-mock-barcode').val() || $('#wcbp-mock-sku').val() || 'SKU-001';
			text = '<div style="font:6pt/1.1 \'Courier New\',monospace;letter-spacing:.5px;flex-shrink:0;padding-top:1px">' + esc(val) + '</div>';
		}
		return '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;width:100%;height:100%;min-height:0">' + svg + text + '</div>';
	}

	// ── Preview renderer ─────────────────────────────────────────────────────
	function renderPreview(barcodeSvg) {
		var w      = parseFloat($('#wcbp-width-in').val())        || 2.625;
		var h      = parseFloat($('#wcbp-height-in').val())       || 1.0;
		var layout = $('input[name="layout"]:checked').val()      || 'vertical';
		var ratio  = parseInt($('#wcbp-barcode-ratio').val(), 10) || 60;
		var rest   = 100 - ratio;
		var isHoriz = (layout === 'horizontal');

		var showCompany     = $('#wcbp-field-company_name').is(':checked');
		var companyName     = $('#wcbp-mock-company').val() || '';
		var companyFontSize = parseInt($('#wcbp-company-font-size').val(), 10) || 10;
		var companyPadding  = parseInt($('#wcbp-company-padding').val(), 10)   || 2;
		var showName    = $('#wcbp-field-name').is(':checked');
		var showPrice   = $('#wcbp-field-price').is(':checked');
		var showSku     = $('#wcbp-field-sku').is(':checked');

		var mockName  = $('#wcbp-mock-name').val()  || 'Sample Product';
		var mockPrice = $('#wcbp-mock-price').val() || '0.00';
		var mockSku   = $('#wcbp-mock-sku').val()   || 'SKU-001';

		var pxW = Math.round(w * 96);
		var pxH = Math.round(h * 96);

		var $prev = $('#wcbp-label-preview');

		// ── Visual layout preview ──────────────────────────────────────────────
		if (layout === 'visual') {
			var jsonStr = (document.getElementById('wcbp-visual-layout-json') || {value: ''}).value || '';
			var vEls = [];
			try { vEls = jsonStr ? JSON.parse(jsonStr) : []; } catch (e) { vEls = []; }

			$prev.css({
				width      : pxW + 'px',
				height     : pxH + 'px',
				position   : 'relative',
				overflow   : 'hidden',
				background : '#fff',
				border     : '1px solid #c3c4c7',
				boxSizing  : 'border-box',
				padding    : '1px 3px',
				display    : 'block',
			});

			var innerIn = Math.max(0.25, w - 6 / 96);
			var vHtml = '';
			vEls.forEach(function (el) {
				if (!el.visible) { return; }
				var jc    = el.align === 'right' ? 'flex-end' : (el.align === 'center' ? 'center' : 'flex-start');
				var style = 'position:absolute;left:' + el.x + '%;top:' + el.y + '%;width:' + el.w + '%;height:' + el.h + '%;overflow:hidden;box-sizing:border-box;';
				var content = '';

				if (el.id === 'barcode') {
					style  += 'display:flex;align-items:center;justify-content:center;';
					content = barcodeBlock(barcodeSvg, innerIn * el.w / 100);
				} else {
					style  += 'font-size:' + (el.fontSize || 8) + 'pt;font-weight:' + (el.bold ? '700' : '400') + ';text-align:' + (el.align || 'left') + ';display:flex;align-items:center;justify-content:' + jc + ';font-family:Arial,sans-serif;';
					if      (el.id === 'company') { content = esc(companyName || ''); }
					else if (el.id === 'name')    { content = esc(mockName); }
					else if (el.id === 'price')   { content = esc(mockPrice); }
					else if (el.id === 'sku')     { content = esc(mockSku); }
				}
				vHtml += '<div style="' + style + '">' + content + '</div>';
			});

			$prev.html('<div style="position:relative;width:100%;height:100%;overflow:hidden">' + vHtml + '</div>');
			return;
		}

		// Outer container is always column; company name stacks at the top.
		$prev.css({
			width        : pxW + 'px',
			height       : pxH + 'px',
			display      : 'flex',
			flexDirection: 'column',
			alignItems   : 'stretch',
			background   : '#fff',
			border       : '1px solid #c3c4c7',
			padding      : '1px 3px',
			boxSizing    : 'border-box',
			overflow     : 'hidden',
			gap          : '2px',
		});

		// Company name banner
		var companyHtml = '';
		if (showCompany && companyName) {
			var coStyle = 'font-size:' + companyFontSize + 'px;padding-bottom:' + companyPadding + 'px;font-weight:700;text-align:center;text-transform:uppercase;letter-spacing:.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex-shrink:0';
			companyHtml = '<div style="' + coStyle + '">' + esc(companyName) + '</div>';
		}

		// Barcode block — available width matches LabelRenderer (label minus 3px side padding)
		var innerW = Math.max(0.25, w - 6 / 96);
		// Mirrors LabelRenderer::scannable_ratio(): widen the barcode box until bars can be 1/150in.
		var vbMatch = barcodeSvg ? /viewBox="0 0 (\d+) /.exec(barcodeSvg) : null;
		if (isHoriz && vbMatch) {
			var bcModules = parseInt(vbMatch[1], 10) / (parseInt(getBarcodeParams().mw, 10) || 2);
			var needed = Math.ceil((bcModules / 150 + 0.02) / innerW * 100);
			ratio = Math.max(ratio, Math.min(72, needed));
			rest  = 100 - ratio;
		}
		var barcodeContent = barcodeBlock(barcodeSvg, isHoriz ? innerW * ratio / 100 : innerW);
		var bcFlex = isHoriz
			? 'flex:' + ratio + ' 0 0%;min-width:0;align-self:stretch;'
			: 'flex:' + ratio + ' 0 0%;min-height:0;width:100%;';
		var barcodeHtml = '<div style="' + bcFlex + 'overflow:hidden;display:flex;align-items:center;justify-content:center;">' + barcodeContent + '</div>';

		// Info block
		var infoLines = '';
		if (showName)  infoLines += '<div style="font-weight:700;overflow:hidden;white-space:nowrap;text-overflow:ellipsis">' + esc(mockName) + '</div>';
		if (showPrice) infoLines += '<div>' + esc(mockPrice) + '</div>';
		// Mirrors the renderer: skip SKU when the same value is printed under the bars.
		var mockBc = $('#wcbp-mock-barcode').val() || mockSku;
		var skuDup = getBarcodeParams().showText === '1' && mockBc === mockSku;
		if (showSku && !skuDup) infoLines += '<div style="color:#888;font-size:8px">' + esc(mockSku) + '</div>';

		var infoHtml = '';
		if (infoLines) {
			var inFlex = isHoriz
				? 'flex:' + rest + ' 0 0%;min-width:0;height:100%;'
				: 'flex:' + rest + ' 0 0%;min-height:0;width:100%;';
			infoHtml = '<div style="' + inFlex + 'display:flex;flex-direction:column;justify-content:center;overflow:hidden;line-height:1.4;font-size:9px;font-family:sans-serif">' + infoLines + '</div>';
		}

		// Inner body: barcode + info share this row/column container
		var bodyHtml = '<div style="flex:1;min-height:0;display:flex;flex-direction:' + (isHoriz ? 'row' : 'column') + ';align-items:center;justify-content:center;gap:2px;">' + barcodeHtml + infoHtml + '</div>';

		$prev.html(companyHtml + bodyHtml);
	}

	// ── Main entry: debounce + fetch ─────────────────────────────────────────
	function schedulePreview() {
		var val    = $('#wcbp-mock-barcode').val() || $('#wcbp-mock-sku').val() || 'SKU-001';
		var params = getBarcodeParams();
		clearTimeout(_barcodeTimer);
		_barcodeTimer = setTimeout(function () {
			fetchBarcode(val, params, renderPreview);
		}, 350);
	}

	// ── Event bindings ───────────────────────────────────────────────────────

	// All template form controls (layout, dimensions, fields, etc.)
	$('#wcbp-template-form input, #wcbp-template-form select').on('change input', schedulePreview);

	// Barcode ratio slider — also update the % label
	$('#wcbp-barcode-ratio').on('input', function () {
		$('#wcbp-barcode-ratio-val').text($(this).val() + '%');
		schedulePreview();
	});

	// Company name text, checkbox, font size, padding — redraw immediately (no barcode change)
	$('#wcbp-mock-company, #wcbp-field-company_name, #wcbp-company-font-size, #wcbp-company-padding').on('input change', function () {
		clearTimeout(_barcodeTimer);
		_barcodeTimer = setTimeout(function () {
			var val    = $('#wcbp-mock-barcode').val() || $('#wcbp-mock-sku').val() || 'SKU-001';
			var params = getBarcodeParams();
			var key    = barcodeKey(val, params);
			var cached = _barcodeCache[key];
			renderPreview(cached !== undefined ? cached : '');
		}, 100);
	});

	// Mock name and price — redraw immediately using cached barcode
	$('#wcbp-mock-name, #wcbp-mock-price').on('input', function () {
		clearTimeout(_barcodeTimer);
		_barcodeTimer = setTimeout(function () {
			var val    = $('#wcbp-mock-barcode').val() || $('#wcbp-mock-sku').val() || 'SKU-001';
			var params = getBarcodeParams();
			var key    = barcodeKey(val, params);
			var cached = _barcodeCache[key];
			renderPreview(cached !== undefined ? cached : '');
		}, 150);
	});

	// Mock SKU — mirror to barcode field unless user has customised it separately
	$('#wcbp-mock-sku').on('input', function () {
		if (!$('#wcbp-mock-barcode').data('custom')) {
			$('#wcbp-mock-barcode').val($(this).val());
		}
		schedulePreview();
	});

	// Mock barcode — mark as custom, clear cache for fresh fetch
	$('#wcbp-mock-barcode').on('input', function () {
		$(this).data('custom', true);
		_barcodeCache = {};
		schedulePreview();
	});

	// Barcode design options — clear cache so changed params fetch a new SVG
	$('#wcbp-bc-symbology, #wcbp-bc-module-width, #wcbp-bc-color, #wcbp-bc-height').on('change input', function () {
		_barcodeCache = {};
		schedulePreview();
	});
	$('#wcbp-bc-show-text').on('change', function () {
		_barcodeCache = {};
		schedulePreview();
	});

	// ── Media library for logo ───────────────────────────────────────────────
	$('#wcbp-select-logo').on('click', function (e) {
		e.preventDefault();
		var frame = wp.media({
			title   : wcbpDesigner.strings.select_logo,
			button  : { text: wcbpDesigner.strings.use_image },
			multiple: false,
			library : { type: 'image' },
		});
		frame.on('select', function () {
			var att = frame.state().get('selection').first().toJSON();
			$('#wcbp-logo-id').val(att.id);
			$('#wcbp-logo-preview').attr('src', att.sizes.thumbnail ? att.sizes.thumbnail.url : att.url).show();
			$('#wcbp-remove-logo').show();
		});
		frame.open();
	});

	$('#wcbp-remove-logo').on('click', function () {
		$('#wcbp-logo-id').val('');
		$('#wcbp-logo-preview').attr('src', '').hide();
		$(this).hide();
	});

	// ── Set default template ─────────────────────────────────────────────────
	$(document).on('click', '.wcbp-set-default-tpl', function (e) {
		e.preventDefault();
		var $btn = $(this);
		$.post(wcbpDesigner.ajax_url, {
			action: 'wcbp_set_default_template',
			nonce : wcbpDesigner.nonce,
			id    : $btn.data('id'),
		}, function (res) {
			if (res.success) location.reload();
		});
	});

	// ── Init ─────────────────────────────────────────────────────────────────
	schedulePreview();

}(jQuery));
