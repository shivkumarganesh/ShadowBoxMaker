<?php
/**
 * Inventory management: stock log, scan-to-adjust, scan-to-sell, low stock.
 *
 * @package WCBarcodePro\Inventory
 */

namespace WCBarcodePro\Inventory;

defined( 'ABSPATH' ) || exit;

class InventoryManager {

	private static ?InventoryManager $instance = null;

	public static function get_instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function register_hooks(): void {
		add_action( 'woocommerce_reduce_order_stock', array( $this, 'log_order_stock_reduction' ) );
		add_action( 'wp_ajax_wcbp_inv_lookup',        array( $this, 'ajax_lookup' ) );
		add_action( 'wp_ajax_wcbp_inv_adjust',        array( $this, 'ajax_adjust' ) );
		add_action( 'wp_ajax_wcbp_inv_sell_one',      array( $this, 'ajax_sell_one' ) );
		add_action( 'wp_ajax_wcbp_inv_low_stock',     array( $this, 'ajax_low_stock' ) );
		add_action( 'wp_ajax_wcbp_inv_log',           array( $this, 'ajax_get_log' ) );
		add_action( 'wp_ajax_wcbp_inv_publish_draft', array( $this, 'ajax_publish_draft' ) );
		add_action( 'wp_ajax_wcbp_tally_lookup',      array( $this, 'ajax_tally_lookup' ) );
		add_action( 'wp_ajax_wcbp_tally_set_stock',   array( $this, 'ajax_tally_set_stock' ) );
		add_action( 'wp_ajax_wcbp_tally_queue',       array( $this, 'ajax_tally_queue' ) );
	}

	// ── Core methods ─────────────────────────────────────────────────────────

	public function lookup_by_barcode( string $barcode ): ?array {
		$barcode = trim( $barcode );
		if ( '' === $barcode ) {
			return null;
		}

		global $wpdb;

		// Query _sku directly — works for all post statuses including draft.
		// wc_get_product_id_by_sku() uses wc_product_meta_lookup which may miss drafts.
		$product_id = (int) $wpdb->get_var( $wpdb->prepare( // phpcs:ignore WordPress.DB
			"SELECT p.ID FROM {$wpdb->posts} p
			 INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID
			 WHERE pm.meta_key = '_sku' AND pm.meta_value = %s
			   AND p.post_type IN ('product','product_variation')
			   AND p.post_status NOT IN ('trash','auto-draft')
			 LIMIT 1",
			$barcode
		) );

		// Fallback: EAN meta.
		if ( ! $product_id ) {
			$product_id = (int) $wpdb->get_var( $wpdb->prepare( // phpcs:ignore WordPress.DB
				"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key=%s AND meta_value=%s LIMIT 1",
				\WCBarcodePro\Barcode\EanManager::META_KEY,
				$barcode
			) );
		}

		if ( ! $product_id ) {
			return null;
		}

		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return null;
		}

		// A size/color label resolves to its variation; report the parent too so stock changes and the
		// stock log are recorded against the right product.
		$is_variation = $product->is_type( 'variation' );
		$parent_id    = $is_variation ? $product->get_parent_id() : $product_id;

		return array(
			'product_id'    => $parent_id,
			'variation_id'  => $is_variation ? $product_id : 0,
			'name'          => $product->get_name(),
			'sku'           => $product->get_sku(),
			'status'        => $product->get_status(),
			'stock_qty'     => (int) $product->get_stock_quantity(),
			'stock_status'  => $product->get_stock_status(),
			'manage_stock'  => (bool) $product->get_manage_stock(),
			'edit_url'      => get_edit_post_link( $parent_id, 'raw' ),
			'image_url'     => get_the_post_thumbnail_url( $product_id, 'thumbnail' ) ?: ( get_the_post_thumbnail_url( $parent_id, 'thumbnail' ) ?: '' ),
		);
	}

	// ── Tally (scan-to-count) ────────────────────────────────────────────────

	/**
	 * A product and every size/color it has (or itself, for a simple product), with stock and
	 * labels still waiting in the print queue — what the Tally tab counts against.
	 */
	public function tally_product( int $product_id, int $scanned_id = 0 ): ?array {
		$product = wc_get_product( $product_id );
		if ( ! $product || $product->is_type( 'variation' ) ) {
			return null;
		}

		global $wpdb;
		$queued = array();
		foreach ( (array) $wpdb->get_results( $wpdb->prepare( // phpcs:ignore WordPress.DB
			"SELECT variation_id, SUM(quantity) AS qty FROM {$wpdb->prefix}wcbp_print_queue
			 WHERE product_id = %d AND status = 'pending' GROUP BY variation_id",
			$product_id
		), ARRAY_A ) as $row ) {
			$queued[ (int) $row['variation_id'] ] = (int) $row['qty'];
		}

		$items = array();
		if ( $product->is_type( 'variable' ) ) {
			foreach ( $product->get_children() as $vid ) {
				$variation = wc_get_product( (int) $vid );
				// Disabled variations are left out unless that is the label just scanned.
				if ( ! $variation || ( 'publish' !== $variation->get_status() && (int) $vid !== $scanned_id ) ) {
					continue;
				}
				$label   = \WCBarcodePro\wcbp_variation_label( $variation );
				$items[] = $this->tally_item( $variation, '' !== $label ? $label : $variation->get_name(), $queued[ (int) $vid ] ?? 0 );
			}
		} else {
			$items[] = $this->tally_item( $product, $product->get_name(), $queued[0] ?? 0 );
		}

		return array(
			'product_id' => $product_id,
			'name'       => $product->get_name(),
			'type'       => $product->get_type(),
			'image_url'  => get_the_post_thumbnail_url( $product_id, 'thumbnail' ) ?: '',
			'edit_url'   => get_edit_post_link( $product_id, 'raw' ),
			'scanned_id' => $scanned_id,
			'items'      => $items,
		);
	}

	private function tally_item( \WC_Product $item, string $label, int $queued ): array {
		$id    = $item->get_id();
		$codes = array_values( array_filter( array(
			(string) get_post_meta( $id, '_sku', true ),
			(string) get_post_meta( $id, \WCBarcodePro\Barcode\EanManager::META_KEY, true ),
		) ) );
		// Only its own count: a variation that borrows the parent's stock reports 'parent', not true.
		$tracked = true === $item->managing_stock();
		return array(
			'id'      => $id,
			'label'   => $label,
			'sku'     => $item->get_sku(),
			'codes'   => $codes,
			'stock'   => $tracked ? (int) $item->get_stock_quantity() : null,
			'queued'  => $queued,
		);
	}

	/**
	 * Is $item_id this product itself (simple) or one of its variations?
	 */
	private function tally_item_of( int $product_id, int $item_id ): ?\WC_Product {
		$item = wc_get_product( $item_id );
		if ( ! $item ) {
			return null;
		}
		if ( $item_id === $product_id && ! $item->is_type( 'variable' ) && ! $item->is_type( 'variation' ) ) {
			return $item;
		}
		return ( $item->is_type( 'variation' ) && $item->get_parent_id() === $product_id ) ? $item : null;
	}

	public function ajax_tally_lookup(): void {
		check_ajax_referer( 'wcbp_inventory', 'nonce' );
		if ( ! \WCBarcodePro\wcbp_current_user_can_manage() ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'woo-barcode-pro' ) ) );
		}
		$barcode = sanitize_text_field( wp_unslash( $_POST['barcode'] ?? '' ) );
		$found   = $this->lookup_by_barcode( $barcode );
		$tally   = $found ? $this->tally_product( (int) $found['product_id'], (int) ( $found['variation_id'] ?: $found['product_id'] ) ) : null;
		if ( ! $tally ) {
			wp_send_json_error( array(
				/* translators: %s: scanned barcode value */
				'message' => sprintf( __( 'No product found for "%s".', 'woo-barcode-pro' ), $barcode ),
			) );
		}
		wp_send_json_success( $tally );
	}

	/**
	 * Set the stock of one or more sizes/colors of a product: items[] = [ id, qty ].
	 */
	public function ajax_tally_set_stock(): void {
		check_ajax_referer( 'wcbp_inventory', 'nonce' );
		if ( ! \WCBarcodePro\wcbp_current_user_can_manage() ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'woo-barcode-pro' ) ) );
		}
		$product_id = (int) ( $_POST['product_id'] ?? 0 );
		$items      = (array) ( $_POST['items'] ?? array() );

		$changes = array();
		foreach ( $items as $row ) {
			$item = is_array( $row ) ? $this->tally_item_of( $product_id, (int) ( $row['id'] ?? 0 ) ) : null;
			$qty  = is_array( $row ) ? (int) ( $row['qty'] ?? -1 ) : -1;
			if ( ! $item || $qty < 0 || $qty > 99999 ) {
				wp_send_json_error( array( 'message' => __( 'Invalid stock change.', 'woo-barcode-pro' ) ) );
			}
			$changes[] = array( $item, $qty );
		}
		if ( ! $changes ) {
			wp_send_json_error( array( 'message' => __( 'Nothing to change.', 'woo-barcode-pro' ) ) );
		}

		foreach ( $changes as list( $item, $qty ) ) {
			// A size that borrowed the parent's stock gets its own count from now on.
			if ( true !== $item->managing_stock() ) {
				$item->set_manage_stock( true );
				$item->save();
			}
			$variation_id = $item->is_type( 'variation' ) ? $item->get_id() : 0;
			$this->adjust_stock( $product_id, $variation_id, $qty, 'tally', __( 'Tally edit', 'woo-barcode-pro' ) );
		}

		wp_send_json_success( $this->tally_product( $product_id ) );
	}

	/**
	 * Queue labels for sizes/colors of a product: items[] = [ id, qty ].
	 */
	public function ajax_tally_queue(): void {
		check_ajax_referer( 'wcbp_inventory', 'nonce' );
		if ( ! \WCBarcodePro\wcbp_current_user_can_manage() ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'woo-barcode-pro' ) ) );
		}
		$product_id = (int) ( $_POST['product_id'] ?? 0 );
		$label_id   = (int) get_post_meta( $product_id, '_wcbp_label_template_id', true );
		$queue      = \WCBarcodePro\Admin\PrintQueue::get_instance();

		$adds = array();
		foreach ( (array) ( $_POST['items'] ?? array() ) as $row ) {
			$item = is_array( $row ) ? $this->tally_item_of( $product_id, (int) ( $row['id'] ?? 0 ) ) : null;
			$qty  = is_array( $row ) ? (int) ( $row['qty'] ?? 0 ) : 0;
			if ( ! $item || $qty < 1 || $qty > 999 ) {
				wp_send_json_error( array( 'message' => __( 'Invalid label request.', 'woo-barcode-pro' ) ) );
			}
			$adds[] = array( $item, $qty );
		}
		if ( ! $adds ) {
			wp_send_json_error( array( 'message' => __( 'Nothing to queue.', 'woo-barcode-pro' ) ) );
		}

		$labels = 0;
		foreach ( $adds as list( $item, $qty ) ) {
			$queue->add( $product_id, $qty, $item->is_type( 'variation' ) ? $item->get_id() : 0, $label_id );
			$labels += $qty;
		}

		$tally            = $this->tally_product( $product_id );
		$tally['message'] = sprintf(
			/* translators: %d: number of labels */
			_n( '%d label added to the print queue.', '%d labels added to the print queue.', $labels, 'woo-barcode-pro' ),
			$labels
		);
		$tally['queue_count'] = $queue->get_count();
		wp_send_json_success( $tally );
	}

	public function adjust_stock( int $product_id, int $variation_id, int $new_qty, string $reason = 'manual', string $note = '' ): array {
		$id      = $variation_id > 0 ? $variation_id : $product_id;
		$product = wc_get_product( $id );
		if ( ! $product ) {
			return array( 'success' => false, 'message' => __( 'Product not found.', 'woo-barcode-pro' ) );
		}

		$old_qty = (int) $product->get_stock_quantity();
		wc_update_product_stock( $product, $new_qty, 'set' );
		$this->log_change( $product_id, $variation_id, $old_qty, $new_qty, $reason, 0, $note );

		return array(
			'success' => true,
			'old_qty' => $old_qty,
			'new_qty' => $new_qty,
			'change'  => $new_qty - $old_qty,
			'status'  => $new_qty <= 0 ? 'outofstock' : 'instock',
		);
	}

	public function sell_one( int $product_id, int $variation_id = 0 ): array {
		$id      = $variation_id > 0 ? $variation_id : $product_id;
		$product = wc_get_product( $id );
		if ( ! $product ) {
			return array( 'success' => false, 'message' => __( 'Product not found.', 'woo-barcode-pro' ) );
		}
		if ( ! $product->get_manage_stock() ) {
			return array( 'success' => false, 'message' => __( 'Stock tracking is not enabled for this product.', 'woo-barcode-pro' ) );
		}

		$old_qty = (int) $product->get_stock_quantity();
		if ( $old_qty <= 0 ) {
			return array( 'success' => false, 'message' => __( 'Already out of stock.', 'woo-barcode-pro' ) );
		}

		$new_qty = $old_qty - 1;
		wc_update_product_stock( $product, $new_qty, 'set' );
		$this->log_change(
			$product_id, $variation_id, $old_qty, $new_qty, 'scan_sell', 0,
			__( 'In-person sale via barcode scan', 'woo-barcode-pro' )
		);

		return array(
			'success' => true,
			'old_qty' => $old_qty,
			'new_qty' => $new_qty,
			'status'  => $new_qty <= 0 ? 'outofstock' : 'instock',
		);
	}

	public function log_change( int $product_id, int $variation_id, int $old_qty, int $new_qty, string $reason, int $order_id = 0, string $note = '' ): void {
		global $wpdb;
		$wpdb->insert( // phpcs:ignore WordPress.DB
			$wpdb->prefix . 'wcbp_stock_log',
			array(
				'product_id'   => $product_id,
				'variation_id' => $variation_id,
				'old_qty'      => $old_qty,
				'new_qty'      => $new_qty,
				'change_qty'   => $new_qty - $old_qty,
				'reason'       => sanitize_key( $reason ),
				'order_id'     => $order_id,
				'user_id'      => get_current_user_id(),
				'note'         => sanitize_text_field( $note ),
			),
			array( '%d', '%d', '%d', '%d', '%d', '%s', '%d', '%d', '%s' )
		);
	}

	public function log_order_stock_reduction( \WC_Order $order ): void {
		foreach ( $order->get_items() as $item ) {
			/** @var \WC_Order_Item_Product $item */
			$product = $item->get_product();
			if ( ! $product || ! $product->get_manage_stock() ) {
				continue;
			}
			$product_id   = $item->get_product_id();
			$variation_id = $item->get_variation_id();
			$qty_sold     = (int) $item->get_quantity();
			$new_qty      = (int) $product->get_stock_quantity();
			$old_qty      = $new_qty + $qty_sold;

			$this->log_change(
				$product_id, $variation_id, $old_qty, $new_qty, 'order',
				$order->get_id(),
				sprintf(
					/* translators: 1: order ID, 2: qty sold */
					__( 'Order #%1$d — sold %2$d unit(s)', 'woo-barcode-pro' ),
					$order->get_id(), $qty_sold
				)
			);
		}
	}

	public function get_low_stock( int $threshold = 5 ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( // phpcs:ignore WordPress.DB
			"SELECT p.ID AS product_id, p.post_title AS name,
			        pm_sku.meta_value    AS sku,
			        CAST(pm_stock.meta_value AS SIGNED) AS stock_qty
			 FROM {$wpdb->posts} p
			 LEFT JOIN {$wpdb->postmeta} pm_sku    ON pm_sku.post_id    = p.ID AND pm_sku.meta_key    = '_sku'
			 LEFT JOIN {$wpdb->postmeta} pm_stock   ON pm_stock.post_id   = p.ID AND pm_stock.meta_key   = '_stock'
			 LEFT JOIN {$wpdb->postmeta} pm_manage  ON pm_manage.post_id  = p.ID AND pm_manage.meta_key  = '_manage_stock'
			 WHERE p.post_type    = 'product'
			   AND p.post_status  = 'publish'
			   AND pm_manage.meta_value = 'yes'
			   AND CAST(pm_stock.meta_value AS SIGNED) <= %d
			 ORDER BY CAST(pm_stock.meta_value AS SIGNED) ASC
			 LIMIT 200",
			$threshold
		), ARRAY_A ) ?: array();
	}

	public function get_log( int $product_id = 0, int $limit = 50, int $offset = 0 ): array {
		global $wpdb;
		if ( $product_id > 0 ) {
			return $wpdb->get_results( $wpdb->prepare( // phpcs:ignore WordPress.DB
				"SELECT l.*, p.post_title AS product_name
				 FROM {$wpdb->prefix}wcbp_stock_log l
				 LEFT JOIN {$wpdb->posts} p ON p.ID = IF(l.variation_id > 0, l.variation_id, l.product_id)
				 WHERE l.product_id = %d
				 ORDER BY l.created_at DESC
				 LIMIT %d OFFSET %d",
				$product_id, $limit, $offset
			), ARRAY_A ) ?: array();
		}

		return $wpdb->get_results( $wpdb->prepare( // phpcs:ignore WordPress.DB
			"SELECT l.*, p.post_title AS product_name
			 FROM {$wpdb->prefix}wcbp_stock_log l
			 LEFT JOIN {$wpdb->posts} p ON p.ID = IF(l.variation_id > 0, l.variation_id, l.product_id)
			 ORDER BY l.created_at DESC
			 LIMIT %d OFFSET %d",
			$limit, $offset
		), ARRAY_A ) ?: array();
	}

	// ── AJAX handlers ─────────────────────────────────────────────────────────

	public function ajax_lookup(): void {
		check_ajax_referer( 'wcbp_inventory', 'nonce' );
		if ( ! \WCBarcodePro\wcbp_current_user_can_manage() ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'woo-barcode-pro' ) ) );
		}
		$barcode = sanitize_text_field( wp_unslash( $_POST['barcode'] ?? '' ) );
		$result  = $this->lookup_by_barcode( $barcode );
		if ( $result ) {
			wp_send_json_success( $result );
		} else {
			wp_send_json_error( array(
				'message' => sprintf(
					/* translators: %s: scanned barcode value */
					__( 'No product found for "%s". Check the barcode printed on the label matches this value.', 'woo-barcode-pro' ),
					$barcode
				),
			) );
		}
	}

	public function ajax_adjust(): void {
		check_ajax_referer( 'wcbp_inventory', 'nonce' );
		if ( ! \WCBarcodePro\wcbp_current_user_can_manage() ) {
			wp_send_json_error();
		}
		$product_id   = (int) ( $_POST['product_id']   ?? 0 );
		$variation_id = (int) ( $_POST['variation_id'] ?? 0 );
		$new_qty      = (int) ( $_POST['new_qty']      ?? 0 );
		$note         = sanitize_text_field( wp_unslash( $_POST['note'] ?? '' ) );

		wp_send_json_success( $this->adjust_stock( $product_id, $variation_id, $new_qty, 'manual', $note ) );
	}

	public function ajax_sell_one(): void {
		check_ajax_referer( 'wcbp_inventory', 'nonce' );
		if ( ! \WCBarcodePro\wcbp_current_user_can_manage() ) {
			wp_send_json_error();
		}
		$product_id   = (int) ( $_POST['product_id']   ?? 0 );
		$variation_id = (int) ( $_POST['variation_id'] ?? 0 );
		$result       = $this->sell_one( $product_id, $variation_id );

		if ( $result['success'] ) {
			wp_send_json_success( $result );
		} else {
			wp_send_json_error( $result );
		}
	}

	public function ajax_low_stock(): void {
		check_ajax_referer( 'wcbp_inventory', 'nonce' );
		if ( ! \WCBarcodePro\wcbp_current_user_can_manage() ) {
			wp_send_json_error();
		}
		$threshold = max( 0, (int) ( $_POST['threshold'] ?? 5 ) );
		wp_send_json_success( array( 'items' => $this->get_low_stock( $threshold ) ) );
	}

	public function ajax_get_log(): void {
		check_ajax_referer( 'wcbp_inventory', 'nonce' );
		if ( ! \WCBarcodePro\wcbp_current_user_can_manage() ) {
			wp_send_json_error();
		}
		$product_id = (int) ( $_POST['product_id'] ?? 0 );
		$page       = max( 1, (int) ( $_POST['page'] ?? 1 ) );
		$limit      = 50;
		$offset     = ( $page - 1 ) * $limit;
		wp_send_json_success( array( 'log' => $this->get_log( $product_id, $limit, $offset ) ) );
	}

	public function ajax_publish_draft(): void {
		check_ajax_referer( 'wcbp_inventory', 'nonce' );
		if ( ! \WCBarcodePro\wcbp_current_user_can_manage() ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'woo-barcode-pro' ) ) );
		}

		$product_id   = (int) ( $_POST['product_id'] ?? 0 );
		$name         = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
		$image_ids    = array_filter( array_map( 'intval', (array) ( $_POST['image_ids'] ?? array() ) ) );
		$category_ids = array_map( 'intval', (array) ( $_POST['category_ids'] ?? array() ) );
		$stock_qty    = max( 0, (int) ( $_POST['stock_qty'] ?? 1 ) );

		if ( ! $product_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid product.', 'woo-barcode-pro' ) ) );
		}
		if ( ! $name ) {
			wp_send_json_error( array( 'message' => __( 'Product name is required.', 'woo-barcode-pro' ) ) );
		}

		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			wp_send_json_error( array( 'message' => __( 'Product not found.', 'woo-barcode-pro' ) ) );
		}

		$product->set_name( $name );
		$product->set_status( 'publish' );
		$product->set_catalog_visibility( 'visible' );

		if ( ! empty( $image_ids ) ) {
			$image_ids = array_values( $image_ids );
			$product->set_image_id( $image_ids[0] );
			if ( count( $image_ids ) > 1 ) {
				$product->set_gallery_image_ids( array_slice( $image_ids, 1 ) );
			}
		}

		// Stock.
		$product->set_manage_stock( true );
		$product->set_stock_quantity( $stock_qty );
		$product->set_stock_status( $stock_qty > 0 ? 'instock' : 'outofstock' );
		if ( ! empty( $category_ids ) ) {
			$product->set_category_ids( $category_ids );
		}

		$product->save();

		wp_send_json_success( array(
			'product_id' => $product_id,
			'edit_url'   => get_edit_post_link( $product_id, 'raw' ),
			'name'       => $name,
		) );
	}

	// ── Admin page ────────────────────────────────────────────────────────────

	public function render_page(): void {
		if ( ! \WCBarcodePro\wcbp_current_user_can_manage() ) {
			wp_die( esc_html__( 'Permission denied.', 'woo-barcode-pro' ) );
		}
		$low_stock_threshold = (int) get_option( 'wcbp_low_stock_threshold', 5 );
		include WCBP_PLUGIN_DIR . 'templates/admin/inventory.php';
	}
}
